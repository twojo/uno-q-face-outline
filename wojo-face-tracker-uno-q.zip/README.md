<div align="center">

# Wojo's Uno Q Face Outline Tracker Demo

### Real-Time Face Tracking on the Arduino Uno Q

<br/>

[![Arduino](https://img.shields.io/badge/Arduino-Uno_Q-00878F?style=for-the-badge&logo=arduino&logoColor=white)](https://docs.arduino.cc/hardware/uno-q/)
[![Qualcomm](https://img.shields.io/badge/Qualcomm-QRB2210-3253DC?style=for-the-badge&logo=qualcomm&logoColor=white)](https://www.qualcomm.com/products/technology/processors)
[![MediaPipe](https://img.shields.io/badge/MediaPipe-Face_Landmarker-4285F4?style=for-the-badge&logo=google&logoColor=white)](https://ai.google.dev/edge/mediapipe/solutions/vision/face_landmarker)
[![App Lab](https://img.shields.io/badge/App_Lab-Bricks_SDK-00878F?style=for-the-badge&logo=arduino&logoColor=white)](https://docs.arduino.cc/software/app-lab/)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

<br/>

**478-point face landmarks &nbsp;|&nbsp; Up to 2 simultaneous faces &nbsp;|&nbsp; Expression detection &nbsp;|&nbsp; LED matrix feedback**

<br/>

A dual-processor edge AI demo built for the [Arduino Uno Q](https://docs.arduino.cc/hardware/uno-q/) --
Qualcomm QRB2210 + STM32U585 working together through
[Arduino App Lab](https://docs.arduino.cc/software/app-lab/) and the
[Bricks SDK](https://docs.arduino.cc/software/app-lab/tutorials/bricks).

</div>

<br/>

---

<br/>

## Table of Contents

1. [Why the Arduino Uno Q](#why-the-arduino-uno-q)
2. [App Lab and Bricks](#app-lab-and-bricks)
3. [Features at a Glance](#features-at-a-glance)
4. [Architecture](#architecture)
5. [Quick Start](#quick-start)
6. [Project Structure](#project-structure)
7. [State Diagrams](#state-diagrams)
8. [Performance](#performance)
9. [GPIO Placeholders](#gpio-placeholders)
10. [WebSocket Events](#websocket-events)
11. [Dependencies](#dependencies)
12. [AI Models & Offline Operation](#ai-models--offline-operation)
13. [Advanced Topics](#advanced-topics)
14. [Links & Resources](#links--resources)
15. [Contributing](#contributing)
16. [License](#license)
<br/>

---

<br/>

## Why the Arduino Uno Q

The [Arduino Uno Q](https://docs.arduino.cc/hardware/uno-q/) is **not a typical Arduino**.
It is a single-board computer with an embedded MCU, designed for AI at the edge.

<br/>

<p align="center">
  <img src="https://docs.arduino.cc/static/567189fab6cc1a00404d38e37b42e755/a6d36/uno-q-architecture-3.png" alt="UNO Q board architecture" width="700">
</p>

<br/>

| Component   | Silicon              | Key Specs                                                                          |
|:------------|:---------------------|:-----------------------------------------------------------------------------------|
| **MPU**     | Qualcomm QRB2210     | Quad-core Cortex-A53 @ 2.0 GHz, Adreno 702 GPU, Wi-Fi 5, BT 5.1, 2/4 GB LPDDR4   |
| **MCU**     | STM32U585            | Cortex-M33 @ 160 MHz, 2 MB flash, 786 KB SRAM, Zephyr RTOS                        |
| **Bridge**  | Arduino Bridge RPC   | Built-in serial link between MPU and MCU -- no wiring needed                       |

<br/>

The two processors communicate through a built-in RPC library called **Arduino Bridge**.
This demo exercises the full pipeline: browser-side AI inference, WebSocket telemetry to a
Python coordinator on Debian, Bridge RPC forwarding to the STM32 MCU, and physical feedback
through the built-in 13x8 LED matrix and RGB LED.

<br/>

<p align="center">
  <img src="https://docs.arduino.cc/static/c4c115ced208022ab43299bda7ea661e/a6d36/Simple-pinout-ABX00162.png" alt="UNO Q pinout" width="600">
</p>

<br/>

> **Tip:** For full pinout details, datasheet, schematics, and CAD files, see the
> [official hardware page](https://docs.arduino.cc/hardware/uno-q/) and the
> [UNO Q User Manual](https://docs.arduino.cc/tutorials/uno-q/user-manual/).

<br/>

---

<br/>

## App Lab and Bricks

The [Arduino App Lab](https://docs.arduino.cc/software/app-lab/) is a unified development
environment that lets you combine Arduino sketches, Python scripts, and containerized
Linux applications into a single workflow.

<br/>

<p align="center">
  <img src="https://docs.arduino.cc/static/782ed8393ae066932b79a19418651a50/a6d36/app-lab.png" alt="Arduino App Lab" width="600">
</p>

<br/>

[Bricks](https://docs.arduino.cc/software/app-lab/tutorials/bricks) are code building
blocks that abstract away complexity. Each brick deploys as a Docker container on the
QRB2210 and exposes a Python API. No Docker configuration required.

<br/>

<p align="center">
  <img src="https://docs.arduino.cc/static/c4ba129c26c39fd5f37d2dfed7fee780/a6d36/add-brick-1.png" alt="Adding a Brick in App Lab" width="500">
</p>

<br/>

### Bricks Used in This Demo

| Brick | Role | What It Does |
|:------|:-----|:-------------|
| **`arduino:web_ui`** | Interface | Serves `assets/` as a web application, provides Socket.IO messaging between browser and `python/main.py` |
| **`arduino:video_object_detection`** | Camera + AI | Captures frames from USB camera, runs face detection AI, provides `get_frame()` and `annotated_frame` APIs |

<br/>

**How they work together:**

1. The **`video_object_detection`** brick opens the USB camera and runs AI inference
2. `python/main.py` reads raw frames via `get_frame()`, encodes them as JPEG, and
   streams them to the browser over Socket.IO (`camera_frame` event)
3. The browser draws the frame on a canvas and runs MediaPipe Face Landmarker for
   detailed 478-point face mesh tracking
4. The brick's built-in AI also runs as a **fallback** -- if the browser stops sending
   face data for 10 seconds (e.g. tab closed), the brick's detections drive the MCU

<br/>

### Video Object Detection -- AI Model Options

The `video_object_detection` brick supports multiple AI models. Select the model
in App Lab under **Bricks > AI Models**, or set it in `app.yaml`:

| Model | `app.yaml` Value | Description | Use Case |
|:------|:-----------------|:------------|:---------|
| **Face Detection** | `face-detection` | Lightweight face localizer (YuNet) | **This demo uses it** -- face presence, bounding boxes |
| YOLOX | `yolox` | General-purpose object detection (nano/small/medium) | People, vehicles, 80+ COCO classes |
| FOMO | `fomo` | Fast Objects, More Objects (centroid-only) | Small object counting, low compute |
| Hand Gesture | `hand-gesture` | MediaPipe hand landmark + gesture classifier | Touchless interfaces, sign language |
| PoseNet | `posenet` | Body pose estimation (17 keypoints) | Fitness tracking, safety monitoring |
| Custom (.eim) | Path to `.eim` file | Your own Edge Impulse model | Any custom detection task |

<br/>

```yaml
# app.yaml -- current configuration
bricks:
  - arduino:web_ui: {}
  - arduino:video_object_detection:
      model: face-detection       # Change to yolox, fomo, hand-gesture, etc.
      fps: 15

# To use a custom Edge Impulse model instead:
#  - arduino:video_object_detection:
#      variables:
#        EI_OBJ_DETECTION_MODEL: /data/model.eim
```

<br/>

> **To swap models:** Open App Lab > click the Video Object Detection brick >
> go to the **AI Models** tab > select a different model > click **Save**.
> Or train a custom model via **Train New AI Model** (requires Edge Impulse account).

<br/>

### Other Available Bricks

These bricks are not used in this demo but can be added to `app.yaml`:

| Brick | Category | Description |
|:------|:---------|:------------|
| `arduino:object_detection` | Vision | Static image detection (single-frame, not live video) |
| `arduino:motion_detection` | Sensor | Detects motion from accelerometer/IMU data (not camera) |
| `arduino:sound_generator` | Audio | Audio feedback, alarms, musical elements |
| `arduino:wave_generator` | Audio | Real-time waveform synthesis (Theremin-style) |
| `arduino:database` | Storage | Local data persistence on the UNO Q filesystem |
| `arduino:cloud_ai_assistant` | Cloud | Conversational AI via cloud APIs |
| `arduino:telegram_bot` | Comms | Telegram messaging integration |

<br/>

> **Install tip:** To install this demo, download the repository as a `.zip`, open
> [Arduino App Lab](https://www.arduino.cc/en/software/#app-lab-section),
> click **Import App**, and select the file.

<br/>

---

<br/>

## Features at a Glance

| Feature                        | Description                                                                                                |
|:-------------------------------|:-----------------------------------------------------------------------------------------------------------|
| **478-Point Face Landmarks**   | Google MediaPipe Face Landmarker running in-browser via WASM -- zero setup, no model compilation            |
| **Multi-Face Tracking**        | Up to **2 simultaneous faces** with unique colors per face                                                  |
| **Expression Detection**       | Smile, surprise, eyebrow raise -- mapped to color-coded RGB LED feedback on the MCU                        |
| **Blink & Pupil Tracking**     | Eye Aspect Ratio (EAR) blink detection + iris diameter measurement in real time                            |
| **LED Matrix Visualization**   | 13x8 grayscale bitmaps: smiley (face detected), X (no face), expression icons, IP scroll on boot          |
| **Adaptive Performance**       | Auto-throttles frame processing when FPS drops below 8; recovers when FPS exceeds 14                      |
| **Swappable AI Source**        | Architecture decouples inference from actuation -- swap MediaPipe for App Lab Bricks, AI Hub, or Edge Impulse |
| **Full Boot Diagnostics**      | CPU, RAM, network, DNS, CDN reachability checks printed to terminal on every startup                       |
| **Bridge RPC Handshake**       | MCU retries `mcu_ready` every 3s for up to 3 minutes; MPU acknowledges from a background thread            |
| **GPIO Expansion Ready**       | 5 pre-configured pins (D3-D7) for relay, buzzer, NeoPixel, or Modulino accessories                        |

<br/>

---

<br/>

## Architecture

### System Overview

<br/>

```mermaid
graph TD
    subgraph Browser["Browser (WebUI Brick) -- assets/index.html"]
        MP["MediaPipe Face Landmarker (WASM)<br/>478 landmarks, 4 faces max"]
        CO["Canvas overlay<br/>mesh, outline, iris, HUD, emojis"]
        AP["Adaptive performance<br/>auto-skip frames when FPS < 8"]
        WS_OUT["WebSocket telemetry<br/>face_data, rgb_control, gpio_control"]
    end

    subgraph MPU["Linux MPU (QRB2210) -- python/main.py"]
        WB["WebUI Brick<br/>serves assets/ + WebSocket"]
        BD["Boot diagnostics<br/>CPU, RAM, network, DNS, CDN"]
        BF["Bridge.call forwarding<br/>face state to MCU hardware"]
        AH["AI Hub fallback<br/>optional TFLite on-device"]
    end

    subgraph MCU["STM32 MCU (STM32U585) -- sketch/sketch.ino"]
        LED["13x8 LED matrix<br/>grayscale bitmaps"]
        RGB["RGB LED (LED4, active-low)<br/>status + expression colors"]
        SL["Status LED (LED_BUILTIN)<br/>solid = face present"]
        GPIO["GPIO placeholders D3-D7<br/>relay, buzzer, NeoPixel"]
        BP["10 Bridge providers<br/>event-driven, loop handles retry/timeout"]
    end

    Browser -->|"WebSocket (JSON, throttled 500ms)<br/>injected by Brick SDK at runtime"| MPU
    MPU -->|"Bridge RPC<br/>(Arduino_RouterBridge)"| MCU
```

<br/>

### Data Flow Pipeline

<br/>

```mermaid
graph LR
    A["USB Webcam<br/>(UVC, 640x480)"] -->|"Video frames"| B["Browser<br/>(MediaPipe WASM)"]
    B -->|"WebSocket<br/>(JSON, 500ms)"| C["Python on Debian<br/>(main.py)"]
    C -->|"Bridge RPC"| D["STM32 MCU<br/>(sketch.ino)"]
    B -.->|"AI inference<br/>478 landmarks"| B
    C -.->|"Coordinates<br/>data flow"| C
    D -.->|"LED matrix, RGB,<br/>GPIO control"| D
```

<br/>

### Compute Architecture

The Uno Q has **four distinct compute blocks**:

<br/>

<p align="center">
  <img src="https://www.qualcomm.com/content/dam/qcomm-martech/dm-assets/images/pdp/block_diagram/image/QRB2210-diagram.svg" alt="QRB2210 block diagram" width="600">
</p>

<br/>

| Block    | Silicon                           | Clock     | Role in This Demo                                                                                     |
|:---------|:----------------------------------|:----------|:------------------------------------------------------------------------------------------------------|
| **CPU**  | Quad-core Arm Cortex-A53 (Kryo)   | 2.0 GHz   | Runs Debian Linux, Python coordinator, Docker containers for App Lab Bricks, and the Chromium browser  |
| **GPU**  | Qualcomm Adreno 702               | 845 MHz   | OpenGL ES 3.1, Vulkan 1.1, OpenCL 2.0 -- available for WebGL rendering and TFLite GPU delegate        |
| **DSP**  | Dual-core Qualcomm Hexagon        | --        | Audio signal processing and always-on low-power tasks. *Not used by this demo*                         |
| **MCU**  | STM32U585 Arm Cortex-M33          | 160 MHz   | Runs Arduino sketch on Zephyr OS -- drives LED matrix, RGB LED, status LED, and GPIO                   |

<br/>

> **Architecture Note:** The QRB2210 has **no dedicated TPU or NPU** (no TOPS rating).
> AI inference relies on the CPU and GPU through framework runtimes like TFLite and WASM.
> This is an intentional tradeoff -- the QRB2210 is Qualcomm's entry-tier IoT processor,
> optimized for low power and cost. For NPU-accelerated inference, Qualcomm's higher-tier
> processors (QCS6490, QCS8550) include the Hexagon Tensor Processor.

<br/>

<br/>

---

<br/>

## Quick Start

### Hardware Requirements

| Component       | Details                                                                                                      |
|:----------------|:-------------------------------------------------------------------------------------------------------------|
| **Board**       | [Arduino Uno Q](https://store.arduino.cc/pages/uno-q) (QRB2210 + STM32U585, 2 GB or 4 GB)                   |
| **LED Matrix**  | Built-in 13x8 (no wiring needed)                                                                             |
| **Camera**      | Standard UVC USB webcam                                                                                       |
| **Connection**  | [USB-C multiport adapter](https://store.arduino.cc/products/usb-c-to-hdmi-multiport-adapter-with-ethernet-and-usb-hub) with external power delivery |
| **Browser**     | Chrome or Edge on any device on the same network                                                              |

<br/>

The board can be powered via USB-C (5V 3A), the 5V pin, or VIN (7-24V):

<br/>

<p align="center">
  <img src="https://docs.arduino.cc/static/72456f6873252eb705cfd28538166e8a/a6d36/power-options-3.png" alt="UNO Q power options" width="500">
</p>

<br/>

### Installation

App Lab runs in two modes: **directly on the Uno Q** as a single-board computer
(SBC mode, recommended with the 4 GB variant), or **hosted on your PC** with the
board connected via USB-C.

<br/>

<p align="center">
  <img src="https://docs.arduino.cc/static/a149a5e406178f25376d784b1d615e6d/a6d36/modes-2.png" alt="SBC and PC hosted modes" width="600">
</p>

<br/>

**Get running in five steps:**

1. **Download** this repository as a `.zip` file.

2. **Open** [Arduino App Lab](https://www.arduino.cc/en/software/#app-lab-section) --
   pre-installed on the Uno Q in SBC mode, or install the desktop version on your PC.

3. **Import** -- click **Import App** and select the `.zip` file.

4. **Wait** -- App Lab reads `app.yaml`, compiles the sketch for the STM32 MCU,
   deploys the WebUI Brick, and launches the application automatically.

5. **Connect** -- the LED matrix will display the board's IP address.
   Open that address in Chrome on any device on the same Wi-Fi network.

<br/>

> **Quick SSH setup (yzma style):** If you prefer the terminal over App Lab,
> this project supports a direct-run workflow inspired by the
> [yzma LLM project](https://projecthub.arduino.cc/marc-edgeimpulse/running-local-llms-and-vlms-on-the-arduino-uno-q-with-yzma-74e288):
>
> ```bash
> ssh arduino@<IP>
> git clone https://github.com/wojo/face-tracker-uno-q && cd face-tracker-uno-q
> ./setup.sh                        # installs deps + downloads face detection models
> python3 direct/face_tracker.py    # standalone face tracking (no App Lab needed)
> ```
>
> Or download individual models yzma-style:
> ```bash
> ./model_get.sh --list                     # see available models
> ./model_get.sh face-detection             # download YuNet face detector (233 KB)
> ./model_get.sh face-mesh                  # download 468-landmark mesh model
> ./model_get.sh -u <huggingface_url>       # download any custom ONNX model
> ```
>
> The standalone tracker uses OpenCV YuNet (75K params) for face detection and
> optionally ONNX Runtime for 468-landmark face mesh -- all running natively on
> the Cortex-A53. MCU LED matrix and RGB LED are controlled via the system-level
> `arduino-router` Bridge service (no App Lab required).

<br/>

### First-Time Setup on a Fresh Board

If this is a brand-new Uno Q that has never been connected to App Lab before,
expect several update prompts before the demo runs.

<br/>

<details>
<summary><strong>What App Lab will prompt you to update</strong></summary>

<br/>

| Prompt                             | What It Updates                                    | Action       | What Happens If You Skip                          |
|:-----------------------------------|:---------------------------------------------------|:-------------|:--------------------------------------------------|
| System firmware                    | Linux OS image on the QRB2210 MPU                  | **Accept**   | Risk kernel/driver incompatibilities              |
| Arduino board core (Zephyr)        | Zephyr RTOS platform for STM32 MCU sketches        | **Accept**   | Sketch compilation will likely fail               |
| Board firmware (STM32 bootloader)  | Low-level MCU bootloader                           | **Accept**   | `Bridge.begin()` may hang or fail silently        |
| Brick container updates            | Docker images for WebUI Brick and App Lab services | **Accept**   | Demo cannot start without the WebUI Brick         |

<br/>

</details>

<br/>

**After accepting all updates:**

1. **Wait for reboot.** The board may reboot more than once. Wait for the green
   power LED to stabilize -- this can take **60-90 seconds** on first boot
   after a firmware update.

2. **Connect to Wi-Fi** if not already configured via **App Lab > Settings > Network**.
   The demo needs internet access to download MediaPipe (~4 MB) from
   `cdn.jsdelivr.net` on first load. A service worker (`assets/sw.js`) caches
   all CDN resources and local assets automatically -- after the first
   successful load, the UI works fully offline.

3. **Import the demo** `.zip` and let App Lab compile the sketch (~30-60 seconds).
   The LED matrix will show a boot icon, then a checkmark, then scroll the
   board's IP address.

4. **Open the IP address** in Chrome on any device on the same Wi-Fi network.

<br/>

### Troubleshooting

<details>
<summary><strong>Common issues and fixes</strong></summary>

<br/>

| Symptom                                         | Likely Cause                               | Fix                                                                                      |
|:-------------------------------------------------|:-------------------------------------------|:-----------------------------------------------------------------------------------------|
| Blank screen, no error                           | JavaScript module failed to load           | Open browser console (F12), check network errors -- usually `cdn.jsdelivr.net` unreachable |
| "Cannot Load Face Detection Engine" overlay      | No internet                                | Connect to Wi-Fi and hit the Retry button                                                |
| LED matrix stays on boot icon                    | `Bridge.begin()` stuck (firmware mismatch) | Accept all pending updates in App Lab, re-import                                         |
| "No Camera Detected" overlay                     | No USB webcam plugged in                   | Plug a USB webcam into any USB-A port (MIPI-CSI requires Media Carrier)                  |
| Camera permission denied                         | Browser blocking camera access             | Check browser settings > Site permissions > Camera > Allow                                |
| MCU shows red LED, Python says "MCU ready"       | Normal behavior                            | MCU starts red (idle) -- turns green when first face is detected                         |
| Sketch won't compile                             | Outdated board core                        | Ensure `arduino:zephyr` is installed and up to date                                      |

<br/>

</details>

<br/>

<details>
<summary><strong>Recovery if you declined updates</strong></summary>

<br/>

If you said "No" to one or more update prompts and the demo doesn't work:

1. Open App Lab settings
2. Check for board/firmware/core updates
3. Accept all pending updates
4. Reboot the board
5. Re-import the demo `.zip`

<br/>

> **Note:** The MCU sketch includes an acknowledgement-driven retry mechanism --
> it re-sends `mcu_ready` every 3 seconds for up to 3 minutes after boot. Once the
> MPU receives the signal, it dispatches `mpu_ack` from a background thread (to avoid
> deadlocking the Bridge read loop), and the MCU stops retrying.

<br/>

</details>

<br/>

---

<br/>

## Project Structure

```
.
├── app.yaml                    # App Lab manifest (bricks + metadata)
│
├── python/
│   ├── main.py                 # MPU coordinator -- Bricks + Bridge forwarding
│   └── requirements.txt        # Python runtime dependencies
│
├── sketch/
│   ├── sketch.ino              # MCU firmware -- Bridge.provide() + LED matrix
│   └── sketch.yaml             # Board profile and library dependencies
│
├── assets/                     # Frontend (served by WebUI Brick on device)
│   ├── index.html              # Face tracking UI
│   ├── app.js                  # Application logic
│   ├── style.css               # Stylesheet
│   ├── sw.js                   # Service worker -- caches CDN assets for offline use
│   ├── img/                    # Icons and images
│   └── qualcomm-logo.png       # Branding asset
│
├── direct/
│   └── face_tracker.py         # Standalone tracker (no App Lab required)
│
├── setup.sh                    # Dependency installer for standalone mode
├── model_get.sh                # Model downloader (yzma-style)
└── LICENSE
```

<br/>

---

<br/>

## State Diagrams

### 1. Full System Boot Sequence

Both processors boot in parallel. The MCU completes first (no OS) and waits
for Bridge; the MPU runs Linux, starts Python, then connects.

<br/>

```mermaid
sequenceDiagram
    participant MCU as STM32U585 MCU
    participant MPU as QRB2210 MPU

    Note over MCU: Power-on
    Note over MPU: Power-on

    MCU->>MCU: Serial.begin(115200)
    MCU->>MCU: Print banner + specs
    MCU->>MCU: Configure GPIO pins
    MCU->>MCU: matrix.begin()
    MCU->>MCU: Show smiley bitmap (1.2s)
    MCU->>MCU: Show boot icon (0.8s)
    MPU->>MPU: Linux kernel boot
    MPU->>MPU: Python runtime start
    MPU->>MPU: Import App Lab SDK
    MCU->>MCU: RGB self-test (R/G/B, 300ms each)
    MPU->>MPU: System diagnostics (CPU, RAM, network, DNS, CDN)
    MCU->>MCU: Bridge.begin()
    MCU->>MCU: Register 9 Bridge providers
    MCU->>MCU: Show checkmark bitmap (0.8s)
    MPU->>MPU: Bridge.begin()
    MCU->>MPU: Bridge.call("mcu_ready")
    Note over MPU: _bridge_ready = True
    MCU->>MCU: Set RGB red (idle, waiting)
    MPU->>MCU: safe_bridge_call("scroll_text", IP)
    Note over MCU: Show smiley (scroll_text handler)
    MPU->>MCU: safe_bridge_call("scroll_text", RAM)
    MPU->>MCU: safe_bridge_call("scroll_text", kernel)
    MPU->>MPU: Start WebUI Brick (serve assets/)
    MPU->>MCU: safe_bridge_call("scroll_text", "Face Demo Ready")
    MPU->>MPU: WebSocket server ready
    Note over MPU: BOOT COMPLETE
    Note over MCU: Idle - waiting for Bridge events
    Note over MPU: Idle - waiting for WS/Bridge
```

<br/>

> **Note:** The `scrollText` MCU handler currently displays `frame_smiley` rather
> than scrolling text -- text scrolling requires ArduinoGraphics font rendering
> which is not yet implemented for the Zephyr platform.

<br/>

### 2. Camera Initialization Flow

<br/>

```mermaid
graph TD
    A["Page Load"] --> B["navigator.mediaDevices.getUserMedia()"]
    B -->|SUCCESS| C["Got stream"]
    B -->|ERROR| D{"Check error type"}

    D -->|NotAllowedError| E["Permission denied"]
    D -->|NotFoundError| F["No camera found"]
    D -->|Other| G["Generic error message"]
    E --> H["Show camera-error overlay<br/>with fix instructions"]
    F --> H
    G --> H

    C --> I["Get track settings<br/>label, resolution, frameRate,<br/>facingMode, megapixels"]
    I --> J["cam.srcObject = stream"]
    J -->|onloadeddata| K["Init FaceLandmarker"]
    K -->|onReady| L["Start draw() render loop"]
```

<br/>

<details>
<summary><strong>3. Face Detection and Rendering Pipeline</strong></summary>

<br/>

Every animation frame passes through this pipeline. The adaptive performance
system may skip frames to maintain smooth rendering.

<br/>

```mermaid
graph TD
    A["requestAnimationFrame(draw)"] --> B{"cam paused/ended<br/>or no model?"}
    B -->|YES| Z1["return (skip)"]
    B -->|NO| C{"Same video frame<br/>as last time?"}
    C -->|YES| Z2["return (skip)"]
    C -->|NO| D{"skipFrames > 0<br/>and not our turn?"}
    D -->|YES| Z3["increment counters, return"]
    D -->|NO| E["fl.detectForVideo()<br/>MediaPipe WASM inference<br/>478 landmarks per face"]
    E --> F["Cap faces to MAX_FACES (4)"]
    F --> G["matchFaces()<br/>sorted min-distance,<br/>adaptive thresholds,<br/>800ms TTL survivors"]
    G --> H["For each face:<br/>mesh/outline, iris, pupils,<br/>blinks (EAR), expression,<br/>emojis, head pose, dots, label"]
    H --> I["drawSysOverlay()<br/>CPU/RAM/temp stats"]
    I --> J["updateAdaptivePerf()<br/>check FPS, adjust skip"]
    J --> K["Update HUD (every 500ms)<br/>faces, FPS, latency, pupils,<br/>blinks, yaw/pitch, uptime"]
    K --> L["Emit face_data via WebSocket<br/>throttled to 500ms"]
```

<br/>

</details>

<br/>

<details>
<summary><strong>4. Adaptive Performance State Machine</strong></summary>

<br/>

Monitors FPS over a sliding window and auto-adjusts frame skipping.
Hysteresis gap (8 to 14) prevents rapid toggling.

<br/>

```mermaid
stateDiagram-v2
    [*] --> OPTIMAL
    OPTIMAL --> AUTO_THROTTLED : avg FPS < 8 (over 3+ samples)
    AUTO_THROTTLED --> OPTIMAL : avg FPS > 14 (sustained recovery)

    state OPTIMAL {
        [*] : skipFrames = 0
        [*] : All frames processed
        [*] : Badge OPTIMAL
    }

    state AUTO_THROTTLED {
        [*] : skipFrames = 1
        [*] : Every other frame skipped
        [*] : Badge THROTTLED
    }
```

<br/>

| Parameter            | Value       |
|:---------------------|:------------|
| `lowFpsThreshold`    | 8 FPS       |
| `highFpsThreshold`   | 14 FPS      |
| `fpsWindowSize`      | 5 samples   |
| `checkInterval`      | 2000ms      |
| Min samples needed   | 3           |

<br/>

</details>

<br/>

<details>
<summary><strong>5. Face Tracking Lifecycle</strong></summary>

<br/>

Each detected face gets a persistent monotonic ID (never recycled) and a unique
color from a 4-color palette (blue, orange, green, purple).

<br/>

```mermaid
graph TD
    A["New face detected in frame"] --> B["matchFaces() distance check<br/>Compare centroid to all known faces"]
    B -->|"MATCHED<br/>(dist < threshold)"| C["Update existing<br/>new centroid, reset TTL,<br/>update bounding box"]
    B -->|UNMATCHED| D["Assign new ID<br/>nextFaceId++, pick color,<br/>record birth time"]
    C --> E["TRACKED (active)<br/>Label: Face N - 12s<br/>Unique color overlay<br/>Blink/pupil/expression"]
    D --> E
    E -->|"face disappears<br/>from detection"| F["MISSING (TTL countdown)<br/>800ms grace period"]
    F -->|"Reappears < 800ms"| G["RECOVERED<br/>Resume track, same ID/color"]
    F -->|"TTL expires > 800ms"| H["EXPIRED<br/>Remove from tracked list<br/>ID retired"]
    G --> E
```

<br/>

> Distance matching uses a threshold that scales with face width, sorted by
> global minimum distance, with greedy assignment (closest pair first).
> Max tracked faces: 4 (`MAX_FACES`).

<br/>

</details>

<br/>

<details>
<summary><strong>7. RGB LED State Machine</strong></summary>

<br/>

LED4 is active-low (`LOW` = ON, `HIGH` = OFF).
Supported colors: red, green, blue, yellow, cyan, magenta, white, off.

<br/>

```mermaid
stateDiagram-v2
    [*] --> OFF
    OFF --> SELF_TEST : Boot
    SELF_TEST --> RED_IDLE : Self-test complete

    state SELF_TEST {
        [*] : R then G then B (300ms each)
    }

    state RED_IDLE {
        [*] : Waiting for face
    }

    RED_IDLE --> GREEN_TRACKING : Face detected
    RED_IDLE --> RED_IDLE : No change

    state GREEN_TRACKING {
        [*] : Face present
    }

    GREEN_TRACKING --> GREEN_SMILE : Expression = smile
    GREEN_TRACKING --> BLUE_SURPRISE : Expression = surprise
    GREEN_TRACKING --> YELLOW_EYEBROW : Expression = eyebrow raise
    GREEN_TRACKING --> RED_IDLE : Face lost
```

<br/>

</details>

<br/>

<details>
<summary><strong>8. Overlay Rendering Order</strong></summary>

<br/>

Each frame draws layers in a specific order. The overlay preset controls
which layers are visible.

<br/>

| Layer  | Content                           | Visibility                   |
|:-------|:----------------------------------|:-----------------------------|
| 0      | Video frame (via cam element)     | Always                       |
| 1      | Face mesh tessellation            | Toggleable                   |
| 2      | Face contour / jawline            | Toggleable                   |
| 3      | Eye outline connections           | Toggleable                   |
| 4      | Eyebrow connections               | Toggleable                   |
| 5      | Lip connections                   | Toggleable                   |
| 6      | Face oval (outer contour)         | Toggleable                   |
| 7      | Iris connections + pupil ring     | Toggleable                   |
| 8      | Iris diameter measurement         | Always (when iris visible)   |
| 9      | Landmark dots (478 per face)      | Toggleable                   |
| 10     | Emoji expression indicators       | Toggleable                   |
| 11     | Blink flash (hot pink)            | Triggered on blink           |
| 12     | Face label ("Face N -- 12s")      | Always                       |
| 13     | System stats overlay              | Always (top-right)           |
| 14     | HUD ticker                        | Always (bottom-center)       |

<br/>

**Overlay Presets:**

| Preset                  | Mesh | Outline | Eyes | Brows | Lips | Iris | Dots | Emoji |
|:------------------------|:----:|:-------:|:----:|:-----:|:----:|:----:|:----:|:-----:|
| **Full Mesh+Features**  |  Y   |    Y    |  Y   |   Y   |  Y   |  Y   |  Y   |   Y   |
| **Outline+Features**    |  -   |    Y    |  Y   |   Y   |  Y   |  Y   |  -   |   Y   |
| **Mesh Only**           |  Y   |    -    |  -   |   -   |  -   |  -   |  -   |   -   |
| **Dots Only**           |  -   |    -    |  -   |   -   |  -   |  -   |  Y   |   -   |
| **Minimal**             |  -   |    Y    |  -   |   -   |  -   |  Y   |  -   |   -   |
| **Outline+Emojis**      |  -   |    Y    |  -   |   -   |  Y   |  -   |  -   |   Y   |

<br/>

</details>

<br/>

---

<br/>

## Performance

| Stage                                     | Typical Latency   | Bottleneck                  |
|:------------------------------------------|:------------------|:----------------------------|
| USB camera capture                        | ~67ms (15 FPS)    | UVC webcam frame rate       |
| MediaPipe WASM inference                  | ~5-15ms           | CPU (4x A53 cores)          |
| Canvas rendering (per face)               | ~1-2ms            | GPU compositing             |
| WebSocket emit (throttled)                | 500ms interval    | Intentional throttle        |
| Bridge RPC (MPU to MCU)                   | ~2-5ms            | Serial transport            |
| LED matrix update                         | <1ms              | SPI to matrix driver        |
| **Browser-side (camera to overlay)**      | **~75-90ms**      | **Camera is the ceiling**   |
| **Full loop (camera to LED)**             | **~500-575ms**    | **WebSocket throttle**      |

<br/>

> **Key insight:** Browser-side rendering runs at full frame rate -- the camera
> is the ceiling. The MCU hardware response is gated by the 500ms WebSocket
> throttle, making end-to-end latency ~500-575ms. This throttle is intentional
> to avoid flooding the Bridge RPC channel.

<br/>

The camera is the dominant bottleneck. The QRB2210's dual ISPs support up to
25 MP at 30 FPS through MIPI-CSI, but this demo uses a USB webcam at 640x480 / 15 FPS.
The [UNO Media Carrier](https://docs.arduino.cc/hardware/uno-media-carrier/) with a
MIPI-CSI camera would roughly double the frame rate.

<br/>

---

<br/>

## GPIO Placeholders

Pre-configured pins for extending the demo. All set as `OUTPUT` at boot but
remain `LOW` unless their enable flag is set to `true` in `sketch.ino`. The
MCU enforces a pin allowlist -- only D3-D7 can be toggled, and only when enabled.

<br/>

| Pin     | Name           | Default    | Use Case                                       |
|:--------|:---------------|:-----------|:-----------------------------------------------|
| **D7**  | `PIN_RELAY`    | disabled   | Modulino Relay or generic 5V relay             |
| **D6**  | `PIN_EXT_LED`  | disabled   | WS2812B NeoPixel strip data pin                |
| **D5**  | `PIN_BUZZER`   | disabled   | Piezo buzzer (beep on face detection)          |
| **D4**  | `PIN_AUX_1`    | disabled   | General-purpose (servo, sensor, Modulino)      |
| **D3**  | `PIN_AUX_2`    | disabled   | General-purpose (PWM capable)                  |

<br/>

> **How to use:**
>
> - **Enable in firmware:** Set `enableRelay = true` (etc.) in `sketch.ino`
> - **Control from Python:** `Bridge.call("set_gpio", "7:1")`
> - **Control from browser (App Lab only):** WebSocket `gpio_control` event with `{pin: 7, state: 1}`

<br/>

---

<br/>

## WebSocket Events

| Event                | Direction         | Payload                                                          |
|:---------------------|:------------------|:-----------------------------------------------------------------|
| **`face_data`**      | Browser -> MPU    | `{faces, blinks, expression, pupilL, pupilR, yaw, pitch}`       |
| **`capture_snapshot`** | Browser -> MPU  | Snapshot request                                                 |
| **`rgb_control`**    | Browser -> MPU    | `{"color": "green"}` (App Lab WebSocket only)                    |
| **`gpio_control`**   | Browser -> MPU    | `{"pin": 7, "state": 1}` (App Lab WebSocket only)               |
| **`state_update`**   | MPU -> Browser    | Full face state JSON                                             |
| **`snapshot_ack`**   | MPU -> Browser    | `{"status": "ok", "timestamp": "..."}`                           |
| **`mpu_face_data`**  | MPU -> Browser    | `{faces, source:"mpu", inference_ms, detections}` (AI Hub)      |
| **`ai_status`**      | MPU -> Browser    | `{available, status, model, running, fps, inference_ms}`         |
| **`ai_toggle`**      | Browser -> MPU    | `{enable: true/false}` (start/stop on-device detection)          |

<br/>

---

<br/>

## Dependencies

Designed to pull as few external resources as possible.

<br/>

### MCU (`sketch.ino`)

| Library                    | Version      | Notes                                         |
|:---------------------------|:-------------|:----------------------------------------------|
| **Arduino_RouterBridge**   | 0.4.1        | Bridge RPC (primary dep in `sketch.yaml`)     |
| Arduino_RPClite            | 0.2.1        | Transitive dep of RouterBridge                |
| ArxContainer               | 0.7.0        | Transitive dep of RouterBridge                |
| ArxTypeTraits              | 0.3.2        | Transitive dep of RouterBridge                |
| DebugLog                   | 0.8.4        | Transitive dep of RouterBridge                |
| MsgPack                    | 0.4.2        | Transitive dep of RouterBridge                |
| **Arduino_LED_Matrix**     | (platform)   | Bundled with `arduino:zephyr` board core      |
| **Arduino_Modulino**       | 0.8.0        | I2C Modulino accessory library (Pixels, Buzzer, Knob, etc.) |

<br/>

### MPU (`python/main.py`)

App Lab SDK (`arduino.app_utils`, `arduino.app_bricks.web_ui`,
`arduino.app_bricks.video_objectdetection`) + `Pillow` (frame encoding) + Python stdlib.

**Optional** for on-device AI: `tflite-runtime`, `numpy`, `opencv-python-headless`.

For model compilation on a dev machine (not the Uno Q): `qai-hub`, `qai_hub_models`, `torch`.

<br/>

### Browser (`assets/index.html`)

| Resource                                  | CDN                    | Pinned       | Required                              |
|:------------------------------------------|:-----------------------|:-------------|:--------------------------------------|
| **@mediapipe/tasks-vision**               | jsdelivr               | 0.10.22      | Yes                                   |
| **face_landmarker.task model**            | Google Cloud Storage   | float16/1    | Yes (~4MB, cached by service worker)  |
| Google Fonts (Inter, JetBrains Mono)      | Google Fonts           | latest       | No (degrades to system fonts)         |

<br/>

---

<br/>

## AI Models & Offline Operation

This demo uses three layers of AI inference. After the first run with
internet, everything works fully offline.

<br/>

### Browser-Side: MediaPipe Face Landmarker (Primary)

| Property              | Value                                                                                     |
|:----------------------|:------------------------------------------------------------------------------------------|
| **Model**             | `face_landmarker.task` (float16, ~4 MB)                                                   |
| **Source**             | [Google MediaPipe](https://ai.google.dev/edge/mediapipe/solutions/vision/face_landmarker) |
| **Runtime**           | MediaPipe Tasks-Vision WASM (`@mediapipe/tasks-vision@0.10.22`)                           |
| **Loaded from**       | `cdn.jsdelivr.net` (JS/WASM) + `storage.googleapis.com` (model)                          |
| **Runs on**           | Client browser (GPU via WebGL2, fallback to CPU)                                          |
| **Output**            | 478 face landmarks, 52 blendshapes, facial transformation matrix                         |
| **Used for**          | Face mesh/outline drawing, expression detection, head pose (yaw/pitch), blink detection  |

This is the primary AI engine. It runs entirely in the browser with no
server-side inference. The model and WASM binaries are downloaded from CDN
on first load and cached by a service worker (`assets/sw.js`) for offline use.

<br/>

### App Lab Brick: VideoObjectDetection (Camera + Fallback AI)

| Property              | Value                                                                                     |
|:----------------------|:------------------------------------------------------------------------------------------|
| **Model**             | Face Detection / YuNet (selectable -- see [AI Model Options](#video-object-detection----ai-model-options)) |
| **Runtime**           | App Lab SDK container (`arduino:video_object_detection`)                                  |
| **Configured in**     | `app.yaml` (`model: face-detection`, `fps: 15`)                                          |
| **Runs on**           | QRB2210 MPU (Cortex-A53, on-device)                                                      |
| **Camera role**       | Opens USB camera, provides raw frames via `get_frame()` API                              |
| **AI output**         | Face bounding boxes with confidence scores                                                |
| **Used for**          | (1) Camera frame source for the browser, (2) fallback detection when browser idle 10s    |

This brick serves two purposes: it is the **camera source** (Python reads frames
via `get_frame()` and streams them to the browser over Socket.IO), and it provides
**fallback face detection** when the browser-side MediaPipe has not sent data for
10 seconds (e.g. browser tab closed). The model can be swapped in App Lab's
**Bricks > AI Models** tab without changing any code.

<br/>

### Direct SSH Mode: OpenCV YuNet + ONNX Face Mesh (Standalone)

| Model                 | File                             | Size      | Source                                           | Required    |
|:----------------------|:---------------------------------|:----------|:-------------------------------------------------|:------------|
| **YuNet face detector** | `face_detection_yunet.onnx`    | ~233 KB   | [OpenCV Zoo](https://github.com/opencv/opencv_zoo) | Yes        |
| YuNet INT8 (faster)   | `face_detection_yunet_int8.onnx` | ~150 KB   | OpenCV Zoo                                       | Optional    |
| **Face mesh (468 pts)** | `face_mesh_192x192.onnx`      | ~3 MB     | [PINTO0309](https://github.com/PINTO0309/facemesh_onnx_tensorrt) | Optional |

These models are only used by `direct/face_tracker.py` (the standalone
SSH mode that bypasses App Lab). Download them once via `./setup.sh` or
`./model_get.sh` -- they are stored in `models/` and reused offline.

- **YuNet**: 75K-parameter face detector, runs via OpenCV's DNN module.
  No extra dependencies beyond `opencv-python-headless` and `numpy`.
- **Face mesh**: 468-landmark model (same landmark set as MediaPipe Face
  Mesh). Requires `onnxruntime` (`pip3 install onnxruntime`). If not
  installed or model not found, the tracker gracefully falls back to
  bounding-box-only detection.

<br/>

### Offline Caching Summary

| Component                        | First Run              | Subsequent Runs                  |
|:---------------------------------|:-----------------------|:---------------------------------|
| **Browser UI + MediaPipe**       | Downloads from CDN     | Served from service worker cache |
| **VideoObjectDetection brick**   | Built into App Lab SDK | Always available                 |
| **Direct mode models (YuNet)**   | Downloaded by setup.sh | Stored in `models/` directory    |

After importing the zip into App Lab and opening the browser UI once
with internet, the service worker caches all MediaPipe resources
(JS, WASM binaries, and the 4 MB model file). Every subsequent load
works without internet.

<br/>

---

<br/>

## Advanced Topics

<details>
<summary><strong>Beyond Face Tracking: Industrial and Pro Applications</strong></summary>

<br/>

This demo is a proof-of-concept, but the pattern it demonstrates -- AI inference
feeding into a Python coordinator on Debian, which drives real-time MCU actuation
via Bridge RPC -- applies directly to [Arduino Pro](https://www.arduino.cc/pro/)
industrial use cases.

<br/>

| Application                  | How It Works With This Architecture                                                                                  |
|:-----------------------------|:---------------------------------------------------------------------------------------------------------------------|
| **Access control**           | Replace LED feedback with a relay on D7 for a door strike. `show_face()` = relay HIGH, `show_no_face()` = relay OFF  |
| **Occupancy monitoring**     | Use persistent face count (`MAX_FACES = 4`) and tracking lifecycle. Forward count to BMS via Wi-Fi                   |
| **Safety compliance**        | Swap MediaPipe for `arduino:object_detection` Brick (YOLOX-Nano). Detect PPE/hard hats. Buzzer on D5 for alerts     |
| **Quality inspection**       | Mount MIPI-CSI camera via Media Carrier. Vision model + Python classification + MCU GPIO for reject actuators        |
| **Operator presence**        | Face tracking 800ms TTL as presence signal. Wire D7 to safety interlock relay. MCU at Zephyr real-time priority      |
| **Retail analytics**         | Count foot traffic, measure dwell time via persistent face IDs. Forward to Arduino Cloud dashboards                  |
| **Agriculture**              | Replace camera AI with sensor Bricks (Modulino Movement, Distance). MCU drives pumps, valves, alerts via GPIO       |

<br/>

</details>

<br/>


<br/>

<details>
<summary><strong>Expanding the Hardware</strong></summary>

<br/>

The Uno Q retains the classic UNO form factor for shield compatibility, and adds
two bottom-mounted high-speed connectors (JMEDIA and JMISC) for advanced peripherals.

<br/>

<p align="center">
  <img src="https://docs.arduino.cc/static/7d5a122fd16435d60983ecb96c2e490f/a6d36/uno-form-factor.png" alt="UNO form factor" width="500">
</p>

<br/>

**Carrier boards:**

| Carrier                                                                             | What It Adds                                                                                          |
|:------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------------------|
| [**UNO Media Carrier**](https://docs.arduino.cc/hardware/uno-media-carrier/)        | Dual MIPI-CSI camera connectors (RPi compatible), MIPI-DSI display output, three 3.5 mm audio jacks  |
| [**UNO Breakout Carrier**](https://docs.arduino.cc/hardware/uno-breakout-carrier/)  | Full breakout of JMEDIA/JMISC signals to 2.54 mm headers -- audio, I2C, SPI, UART, PWM, PSSI, GPIO   |

<br/>

**Qwiic / Modulino sensors** (no soldering, I2C on Wire1):

| Modulino                                                                              | Use With This Demo                                                           |
|:--------------------------------------------------------------------------------------|:-----------------------------------------------------------------------------|
| [**Modulino Movement**](https://docs.arduino.cc/hardware/modulino-movement/)          | LSM6DSOX accelerometer/gyroscope -- detect tilt/movement while tracking      |
| [**Modulino Distance**](https://docs.arduino.cc/hardware/modulino-distance/)          | Time-of-flight -- measure viewer distance from camera                        |
| [**Modulino Buttons**](https://docs.arduino.cc/hardware/modulino-buttons/)            | Physical buttons -- cycle overlay presets or toggle tracking                  |

<br/>

</details>

<br/>

<details>
<summary><strong>Arduino Cloud Integration (Future)</strong></summary>

<br/>

The current demo runs entirely on the local network.
[Arduino Cloud](https://docs.arduino.cc/arduino-cloud/) could add:

- Log timestamp and screenshot of each new face detection to a cloud Thing
- Persistent face count across sessions (daily/weekly)
- Live dashboard showing tracking state, uptime, and system health remotely
- Webhook notifications when a face is detected (or absent for a threshold period)
- Historical data export via [Arduino Cloud's built-in data export](https://docs.arduino.cc/arduino-cloud/features/iot-cloud-historical-data/)

<br/>

> The Uno Q's built-in Wi-Fi and the WebUI Brick's `web_ui.expose_api()` pattern
> make this feasible without restructuring the app.

<br/>

</details>

<br/>

<details>
<summary><strong>Advanced AI Model Options</strong></summary>

<br/>

> **Warning:** The sections below describe AI model workflows that are technically
> possible on the Uno Q's QRB2210 but are **not part of this demo** and **not included
> in the App Lab zip**. They require additional software (`tflite-runtime`, OpenCV,
> numpy), a camera on the MPU, and in some cases cloud accounts.

<br/>

#### What is Qualcomm AI Hub?

[Qualcomm AI Hub](https://aihub.qualcomm.com/) takes pre-trained AI models (PyTorch,
ONNX, TensorFlow) and compiles them into optimized runtimes for specific Qualcomm chipsets.

<br/>

```mermaid
graph LR
    subgraph Input["Your Model"]
        A["PyTorch / ONNX /<br/>TF-Keras / JAX"]
    end

    subgraph Cloud["AI Hub Cloud"]
        B["1. OPTIMIZE<br/>Quantize INT8, fuse ops"]
        C["2. COMPILE<br/>Target: QRB2210<br/>Runtime: TFLite or QNN"]
        D["3. PROFILE<br/>Latency, FPS, memory,<br/>layer-by-layer"]
        B --> C --> D
    end

    subgraph Device["Target Device"]
        E["Uno Q (QRB2210)<br/>or any Snapdragon"]
    end

    A -->|upload| B
    D -->|"download .tflite / .dlc"| E
```

<br/>

#### On-Device Inference via AI Hub

The `python/face_detector_mpu.py` module implements an alternative path: face detection
runs natively on the QRB2210 using `tflite-runtime`, bypassing the browser.

<br/>

```mermaid
graph LR
    A["Camera (v4l2/USB)"] --> B["OpenCV capture"]
    B --> C["TFLite inference (CPU)"]
    C --> D["Face results"]
    D --> E["Bridge RPC to MCU<br/>(LED/RGB)"]
    D --> F["WebSocket to Browser<br/>(overlay)"]
```

<br/>

**TFLite delegates on QRB2210:**

<br/>

<p align="center">
  <img src="https://raw.githubusercontent.com/tensorflow/tensorflow/master/tensorflow/lite/g3doc/images/convert/workflow.svg" alt="TensorFlow Lite conversion and inference workflow" width="700">
</p>

<br/>

```mermaid
graph TD
    A[".tflite model file"] --> B["TFLite Interpreter<br/>Load, Allocate, Invoke"]
    B --> C{"Delegate selection"}
    C --> D["XNNPACK (CPU)<br/>DEFAULT - reliable"]
    C --> E["GPU (Adreno 702)<br/>Available but unreliable<br/>for landmarks"]
    C --> F["Hexagon (NPU)<br/>N/A on QRB2210"]
```

<br/>

**Hardware constraints on the QRB2210:**

| Spec         | Value                                | Impact                                                         |
|:-------------|:-------------------------------------|:---------------------------------------------------------------|
| **CPU**      | Cortex-A53 @ 2.0 GHz (4 cores)      | TFLite runs here. INT8 face_det_lite: ~5-15ms/frame            |
| **GPU**      | Adreno 702 @ 845 MHz                | GPU delegate available but slower for small models             |
| **NPU/TPU**  | None (0 TOPS)                        | No hardware neural network accelerator                         |
| **Camera**   | USB (UVC) or MIPI-CSI via Carrier    | 640x480 @ 15 FPS ceiling for USB                               |
| **RAM**      | 2 GB or 4 GB LPDDR4                 | Model + OpenCV + TFLite uses ~80-120 MB                        |

<br/>

**Setup:**

```bash
# On your dev machine -- compile model for QRB2210 via AI Hub cloud
pip install qai-hub qai_hub_models torch
qai-hub configure --api_token YOUR_TOKEN
python python/ai_hub_setup.py --compile --model face_det_lite --device QRB2210

# Copy the .tflite file to the Uno Q
scp python/models/face_det_lite.tflite unoq:~/face-demo/python/models/

# On the Uno Q -- install runtime deps
pip install tflite-runtime numpy opencv-python-headless

# Reboot the app -- it auto-discovers .tflite files in python/models/ at boot
```

<br/>

> **Tip:** The system always works without AI Hub models. Missing dependencies
> result in graceful fallback to browser-only mode (MediaPipe WASM).

<br/>

**Inference Approaches Comparison:**

| Approach                         | In This Demo?  | Where It Runs          | Setup Effort                          | Best For                               |
|:---------------------------------|:--------------:|:-----------------------|:--------------------------------------|:---------------------------------------|
| **Browser (MediaPipe WASM)**     | **Yes**        | Client browser         | Zero -- loads from CDN                | Demos, face landmarks (this demo)      |
| **App Lab Brick**                | Partially      | QRB2210 Docker         | Low -- add one line to `app.yaml`     | Standard tasks (object detection)      |
| AI Hub TFLite                    | No             | QRB2210 MPU native     | Medium -- compile + install deps      | Optimized headless inference           |
| Hugging Face model               | No             | QRB2210 MPU native     | Medium-High -- export to TFLite       | Research models, niche tasks           |
| Custom model (Edge Impulse)      | No             | QRB2210 MPU native     | High -- train + export + deploy       | Domain-specific, proprietary data      |

<br/>

#### Bringing a Hugging Face Model

Models on [Hugging Face Hub](https://huggingface.co/) that can be exported to TFLite
format can run on the Uno Q using the same `tflite-runtime` infrastructure.

<br/>

```mermaid
graph LR
    subgraph HF["Hugging Face Hub"]
        A["PyTorch / TF-Keras /<br/>JAX / ONNX models"]
    end

    subgraph Convert["Conversion"]
        B["Option A: optimum-cli<br/>export tflite --quantize int8"]
        C["Option B: AI Hub<br/>compile for QRB2210"]
    end

    subgraph UnoQ["Uno Q (QRB2210)"]
        D["python/models/<br/>model.tflite<br/>auto-discovered at boot"]
    end

    A -->|"A"| B -->|scp| D
    A -->|"B"| C -->|scp| D
```

<br/>

1. **Export to TFLite** via `optimum-cli export tflite --model google/vit-base-patch16-224 --quantize int8`
2. **Drop the `.tflite` into `python/models/`** -- modify `face_detector_mpu.py` to match input/output signatures if different
3. **Run inference** -- the same `tflite-runtime` runs any valid TFLite model

<br/>

> **Tip:** Stick to mobile-optimized architectures (MobileNetV2/V3, EfficientNet-Lite,
> NanoDet, PicoDet). Models under 5M parameters with 320x320 input run comfortably
> on the A53 cores.

<br/>

#### Bringing a Custom Edge Impulse Model

[Edge Impulse](https://edgeimpulse.com/) trains custom ML models on your own data.
Models trained there export as TFLite and run on the Uno Q identically to AI Hub models.

<br/>

```mermaid
graph LR
    A["1. Collect & Label<br/>images, audio, sensor data"] --> B["2. Design Impulse<br/>signal processing +<br/>learning block"]
    B --> C["3. Train<br/>MobileNet, custom DSP+NN"]
    C --> D["4. Test<br/>live classification"]
    D --> E["5. Deploy<br/>TFLite (int8)"]
    E --> F["Uno Q: python/models/<br/>runs on QRB2210 MPU"]
```

<br/>

> **Note:** Edge Impulse also has a direct Arduino library export (C++), but that targets
> the STM32 MCU which is too constrained for most ML models (Cortex-M33, 786 KB SRAM).
> Use the TFLite export to the MPU side instead.

<br/>

#### AI Model Ecosystem for Uno Q

<br/>

```mermaid
graph TD
    subgraph Demo["THIS DEMO (works out of the box)"]
        MP["Google MediaPipe<br/>478-pt face landmarks<br/>Runs in BROWSER via WASM"]
        BK["Arduino App Lab Bricks<br/>web_ui, obj_det, motion<br/>Runs on MPU (Docker)"]
    end

    subgraph Advanced["ADVANCED (requires additional setup)"]
        AH["Qualcomm AI Hub<br/>100+ optimized models<br/>Runs on MPU (tflite-runtime)"]
        HF["Hugging Face<br/>500k+ models<br/>Export to TFLite via optimum"]
        EI["Edge Impulse<br/>Train on YOUR data<br/>Export to TFLite"]
    end

    MP --> PY["Python Coordinator (main.py)<br/>Receives data from ANY source"]
    BK --> PY
    AH --> PY
    HF --> PY
    EI --> PY
    PY --> BR["Bridge RPC to MCU (LED/RGB/GPIO)"]
    PY --> WS["WebSocket to Browser (UI overlay)"]
```

<br/>

#### The Decision Tree

<br/>

```mermaid
graph TD
    Q1{"Need face landmarks<br/>(478 points, expressions, iris)?"}
    Q1 -->|YES| A1["Browser-side MediaPipe<br/>(this demo default)"]
    Q1 -->|NO| Q2{"Pre-built App Lab Brick<br/>for your task?"}
    Q2 -->|YES| A2["Use the Brick<br/>(one line in app.yaml)"]
    Q2 -->|NO| Q3{"Model available on<br/>Qualcomm AI Hub?"}
    Q3 -->|YES| A3["Compile optimized TFLite<br/>for QRB2210"]
    Q3 -->|NO| Q4{"Model available on<br/>Hugging Face?"}
    Q4 -->|YES| A4["Export to TFLite via optimum,<br/>deploy to python/models/"]
    Q4 -->|NO| Q5{"Have your own<br/>training data?"}
    Q5 -->|YES| A5["Train in Edge Impulse,<br/>export TFLite"]
    Q5 -->|NO| A6["Check TF Model Garden,<br/>convert to TFLite"]
```

<br/>

> In all cases, the MCU layer, Bridge providers, WebSocket events, and Python
> coordinator remain the same. **Only the inference source changes.**

<br/>

</details>

<br/>

<details>
<summary><strong>Where the Uno Q Fits in Qualcomm's World</strong></summary>

<br/>

> **Context:** The material below is background reading about Qualcomm's product
> ecosystem, the upcoming Ventuno Q, and industry trends. None of it is required
> to use this demo.

<br/>

#### Qualcomm Dragonwing IoT Processor Lineup

The QRB2210 is Qualcomm's entry-tier IoT processor:

<br/>

| Feature            | QRB2210 (Uno Q)                    | QCS6490                               | QCS8550                              |
|:-------------------|:-----------------------------------|:---------------------------------------|:-------------------------------------|
| **Series**         | Q2 (Dragonwing)                    | Q6 (Dragonwing)                        | Q8 (Dragonwing)                      |
| **CPU**            | 4x Cortex-A53 @ 2.0 GHz           | Kryo 670 (big.LITTLE)                  | Kryo (big.LITTLE)                    |
| **GPU**            | Adreno 702                         | Adreno 643                             | Adreno 740                           |
| **NPU**            | None (0 TOPS)                      | Hexagon DSP + HTA (~12 TOPS)           | Hexagon NPU (~48 TOPS)              |
| **RAM**            | 2-4 GB LPDDR4                      | Up to 8 GB LPDDR4X                     | Up to 16 GB LPDDR5X                  |
| **AI inference**   | CPU/GPU TFLite only                | NPU-accelerated (QNN, SNPE)            | NPU-accelerated (QNN)               |
| **Use case**       | Entry IoT, prototyping, education  | Mid-tier edge AI, smart cameras        | High-end edge AI, robotics          |
| **Approx. cost**   | ~$25                               | ~$80                                   | ~$150+                               |

<br/>

> _QCS6490 and QCS8550 specs are approximate. Consult
> [Qualcomm's product pages](https://www.qualcomm.com/products/technology/processors)
> for exact specifications._

<br/>

#### Uno Q vs Ventuno Q

Qualcomm announced its intent to acquire Arduino in October 2025. The combined
entity is executing a two-board hardware strategy:

<br/>

| Spec            | Arduino Uno Q (Shipping Now)                  | Arduino Ventuno Q (Announced EW 2026)         |
|:----------------|:----------------------------------------------|:----------------------------------------------|
| **MPU**         | Qualcomm QRB2210 (Q2 Series)                  | Qualcomm Dragonwing IQ8 (IQ-8275)             |
| **CPU**         | 4x Cortex-A53 @ 2.0 GHz                      | 8-core Kryo (up to ~2.4 GHz)                  |
| **GPU**         | Adreno 702                                    | Adreno                                        |
| **NPU**         | None (0 TOPS)                                 | Hexagon Tensor (~40 TOPS)                     |
| **RAM**         | 2-4 GB LPDDR4                                 | 16 GB LPDDR5                                  |
| **Storage**     | 16-64 GB eMMC                                 | 64 GB eMMC + M.2 NVMe                         |
| **MCU**         | STM32U585 (Cortex-M33, 786 KB SRAM)           | STM32H5F5 (Cortex-M33, higher SRAM)           |
| **OS**          | Debian Linux + Zephyr                         | Ubuntu/Debian + Zephyr                        |
| **Price**       | ~$90 (4 GB)                                   | ~$300 (expected)                               |
| **Best for**    | Learning, prototyping, IoT gateways           | On-device LLMs, NPU vision, robotics          |

<br/>

Both boards share: dual-brain architecture (MPU + MCU via Bridge), App Lab + Bricks
ecosystem, Arduino IDE/Cloud compatibility, Python (MPU) + C++ Sketch (MCU) programming
model, and the same Bridge API pattern.

<br/>

> _Ventuno Q specs are based on the Embedded World 2026 announcement and may change._

<br/>

#### Qualcomm's Full-Stack Edge AI Ecosystem

Assembled through acquisitions (2024-2025):

<br/>

```mermaid
graph TD
    A["SILICON<br/>Qualcomm (in-house)<br/>Snapdragon, Dragonwing,<br/>Hexagon NPU, AI Hub"] --> E["THE VISION:<br/>One vendor for chip, model,<br/>OS, OTA, IDE, cloud, community"]
    B["AI TOOLCHAIN<br/>Edge Impulse (acq. Mar 2025)<br/>Train custom ML models,<br/>deploy to Qualcomm devices"] --> E
    C["OS + FLEET MGMT<br/>Foundries.io (acq. Mar 2024)<br/>FoundriesFactory, OTA,<br/>secure boot, CI/CD"] --> E
    D["DEVELOPER COMMUNITY<br/>Arduino (announced Oct 2025)<br/>33M+ developers, App Lab,<br/>Arduino Cloud, Bricks"] --> E
```

<br/>

| Stage              | Tool                                  | What It Does                                       |
|:-------------------|:--------------------------------------|:---------------------------------------------------|
| **Prototype**      | Arduino IDE / App Lab                 | Write sketch + Python, test on single board        |
| **Train AI**       | Edge Impulse                          | Train custom model on your data, export TFLite     |
| **Optimize**       | AI Hub                                | Compile + quantize model for QRB2210 or IQ8        |
| **Secure OS**      | FoundriesFactory                      | Hardened Linux, secure boot, container isolation   |
| **Deploy fleet**   | FoundriesFactory + Arduino Cloud      | OTA updates to 10 or 10,000 boards                 |
| **Monitor**        | Arduino Cloud                         | Dashboard, alerts, remote management               |

<br/>

#### Qualcomm Physical AI Stack

<br/>

```mermaid
graph TD
    A["APPLICATIONS<br/>Humanoids, AMRs, Drones,<br/>Smart Cameras, IoT Sensors"]
    B["AI MODELS<br/>AI Hub, Edge Impulse,<br/>Hugging Face, MediaPipe"]
    C["SOFTWARE PLATFORM<br/>App Lab, Bricks, Arduino Cloud,<br/>FoundriesFactory"]
    D["SILICON"]

    A --> B --> C --> D

    D --- D1["IQ10 -- Humanoid/Industrial"]
    D --- D2["IQ8 -- Edge AI/Robotics (VENTUNO Q)"]
    D --- D3["IQ6 -- Smart Cameras"]
    D --- D4["Q8 -- High-end IoT"]
    D --- D5["Q6 -- Mid-tier IoT"]
    D --- D6["Q2 -- Entry IoT (UNO Q)"]
```

<br/>

> The face detection demo running on this Uno Q is a small example of this larger arc.
> The same architectural pattern -- camera input, AI inference, Bridge to MCU, real-time
> actuation -- is how a warehouse robot processes its environment, how a smart camera
> identifies defects, and how a drone navigates autonomously. The Uno Q teaches the
> pattern at an accessible price point.

<br/>

</details>

<br/>

---

<br/>

## Links & Resources

**Arduino Hardware & Software**

| Resource                    | Link                                                                                               |
|:----------------------------|:---------------------------------------------------------------------------------------------------|
| Arduino Uno Q Hardware      | [docs.arduino.cc/hardware/uno-q/](https://docs.arduino.cc/hardware/uno-q/)                         |
| UNO Q User Manual           | [docs.arduino.cc/tutorials/uno-q/user-manual/](https://docs.arduino.cc/tutorials/uno-q/user-manual/) |
| UNO Q Pinout (PDF)          | [ABX00162-full-pinout.pdf](https://docs.arduino.cc/resources/pinouts/ABX00162-full-pinout.pdf)      |
| UNO Q Datasheet (PDF)       | [ABX00162-ABX00173-datasheet.pdf](https://docs.arduino.cc/resources/datasheets/ABX00162-ABX00173-datasheet.pdf) |
| Arduino App Lab             | [docs.arduino.cc/software/app-lab/](https://docs.arduino.cc/software/app-lab/)                     |
| App Lab Bricks              | [docs.arduino.cc/software/app-lab/tutorials/bricks](https://docs.arduino.cc/software/app-lab/tutorials/bricks) |
| Arduino Cloud               | [docs.arduino.cc/arduino-cloud/](https://docs.arduino.cc/arduino-cloud/)                           |
| Buy Arduino Uno Q           | [store.arduino.cc/pages/uno-q](https://store.arduino.cc/pages/uno-q)                               |

<br/>

**AI & ML Platforms**

| Resource                          | Link                                                                                                        |
|:----------------------------------|:------------------------------------------------------------------------------------------------------------|
| Google MediaPipe Face Landmarker  | [ai.google.dev/edge/mediapipe](https://ai.google.dev/edge/mediapipe/solutions/vision/face_landmarker)       |
| Qualcomm AI Hub                   | [aihub.qualcomm.com](https://aihub.qualcomm.com/)                                                          |
| Qualcomm AI Hub Models            | [aihub.qualcomm.com/models](https://aihub.qualcomm.com/models)                                              |
| Edge Impulse                      | [edgeimpulse.com](https://edgeimpulse.com/)                                                                 |
| Hugging Face Hub                  | [huggingface.co/models](https://huggingface.co/models)                                                      |
| TensorFlow Lite Model Garden      | [tensorflow.org/lite/models](https://www.tensorflow.org/lite/models)                                         |

<br/>

**Qualcomm & Industry**

| Resource                           | Link                                                                                                       |
|:-----------------------------------|:-----------------------------------------------------------------------------------------------------------|
| Qualcomm Dragonwing Platform       | [qualcomm.com/products/technology/processors](https://www.qualcomm.com/products/technology/processors)      |
| Foundries.io / FoundriesFactory    | [foundries.io](https://foundries.io/)                                                                      |
| Arduino Ventuno Q (EW 2026)        | [blog.arduino.cc](https://blog.arduino.cc/)                                                                |

<br/>

---

<br/>

## Contributing

Contributions are welcome. If you find a bug, have a feature request, or want
to improve the documentation:

1. **Fork** this repository
2. **Create a branch** for your feature or fix (`git checkout -b feature/my-feature`)
3. **Commit** your changes with clear messages
4. **Push** to your fork and open a **Pull Request**

<br/>

> **Guideline:** Keep the architecture modular -- the inference source should remain
> swappable, and the MCU layer should stay event-driven.

<br/>

---

<br/>

## License

This project is licensed under the **MIT License** -- see the [LICENSE](LICENSE) file for details.

<br/>

---

<div align="center">

<br/>

**Built for the [Arduino Uno Q](https://store.arduino.cc/pages/uno-q/)**

**Qualcomm QRB2210 + STM32U585**

<br/>

*The inference source is swappable. The architecture is the showcase.*

<br/>

</div>
